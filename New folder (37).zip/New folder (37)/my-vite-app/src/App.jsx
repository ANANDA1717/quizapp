// App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ErrorPage from './component/ErrorPage'; // Import the ErrorPage component
import HomePage from './component/HomePage';


function App() {
  return (
    <div>
      {/* Routes define which component should be displayed based on the URL */}
      <Routes>
        <Route path="/" element={<HomePage />} /> {/* Home route */}
        <Route path="*" element={<ErrorPage />} /> {/* Catch-all for invalid routes */}
        
      </Routes>
    </div>
  );
}

export default App;
