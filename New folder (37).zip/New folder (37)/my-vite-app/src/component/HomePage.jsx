import React, { useState, useEffect } from 'react';
import fetchQuizData from './Api'; // Import the fetchQuizData function
import "./styles.css";

const HomePage = () => {
  const [quizData, setQuizData] = useState([]); // Initially an empty array
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [score, setScore] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);  // Track if the quiz is finished
  const [answers, setAnswers] = useState([]); // To store user's answers and whether they were correct or not

  // Set this to true if you want to use mock data, false for API
  const useMockData = false;  // Set to 'true' for mock data, 'false' for real API calls

  useEffect(() => {
    const getQuizData = async () => {
      try {
        const data = await fetchQuizData(useMockData); // Pass 'useMockData' flag
        if (data.error) {
          setError(data.error);
        } else {
          setQuizData(data); // Set quiz data if successfully fetched
        }
      } catch (err) {
        setError('Failed to fetch quiz data');
      }
      setLoading(false); // Set loading to false after data is fetched
    };

    getQuizData();
  }, [useMockData]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  if (quizData.length === 0) {
    return <div>There are no questions available at the moment.</div>;
  }

  const currentQuestion = quizData[currentQuestionIndex];

  const handleAnswer = (selectedAnswer) => {
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
    if (isCorrect) {
      setScore((prevScore) => prevScore + 1); // Increase score if correct
    }

    // Store the user's answer and whether it was correct
    setAnswers((prevAnswers) => [
      ...prevAnswers,
      { question: currentQuestion.question.text, answer: selectedAnswer, isCorrect }
    ]);

    // Move to the next question, or show the result if it's the last question
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setQuizFinished(true); // Set quiz to finished after last question
    }
  };

  // Randomize the options for each question (correct + incorrect answers)
  const options = [currentQuestion.correctAnswer, ...currentQuestion.incorrectAnswers];
  const shuffledOptions = options.sort(() => Math.random() - 0.5); // Shuffle the options randomly

  // Display results page if the quiz is finished
  if (quizFinished) {
    return (
      <div className="card2 font-bold">
        <h2 className='text-teal-800'>QUIZ FINISHED</h2>
        <p>Your score: {score} / {quizData.length}</p>
        <div>
          {answers.map((item, index) => (
            <div key={index} className={`question-result ${item.isCorrect ? 'correct' : 'incorrect'}`}>
              <h3>{item.question}</h3>
              <p>Your Answer: {item.answer}</p>
              <p>{item.isCorrect ? "Correct!" : `Incorrect. Correct Answer: ${quizData[index].correctAnswer}`}</p>
            </div>
          ))}
        </div>
        <button onClick={() => window.location.reload()}>Play Again</button>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row justify-center items-center p-4 space-y-4 md:space-y-0">
      {/* Quiz Card */}
      <div className="card1 bg-white p-6 rounded-4xl shadow-lg w-full md:w-1/2 font-bold text-2xl">
        <h1 className="text-teal-500 font-bold text-5xl text-center">Trivia Quiz</h1>
        <div className="space-y-4 ml-2.5 mt-7">
          <h2>{currentQuestion.question.text}</h2>
          <ul>
            {shuffledOptions.map((option, index) => (
              <li key={index}>
                <button onClick={() => handleAnswer(option)}>{option}</button>
              </li>
            ))}
          </ul>
          <p>Score: {score}</p>
          <p>
            Question {currentQuestionIndex + 1} of {quizData.length}
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
