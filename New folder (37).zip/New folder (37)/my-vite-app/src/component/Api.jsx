const fetchQuizData = async (useMockData = false) => {
  // Return mock data if useMockData is true
  if (useMockData) {
    const mockData = [
      {
        question: { text: "Who was the first President of the United States?" },
        correctAnswer: "George Washington",
        incorrectAnswers: ["Thomas Jefferson", "Abraham Lincoln", "John Adams"]
      },
      {
        question: { text: "In which year did World War I begin?" },
        correctAnswer: "1914",
        incorrectAnswers: ["1912", "1916", "1920"]
      },
      {
        question: { text: "Which ancient civilization built the pyramids?" },
        correctAnswer: "Ancient Egyptians",
        incorrectAnswers: ["Romans", "Greeks", "Mayans"]
      },
      {
        question: { text: "Who was the leader of the Soviet Union during World War II?" },
        correctAnswer: "Joseph Stalin",
        incorrectAnswers: ["Vladimir Lenin", "Leon Trotsky", "Nikita Khrushchev"]
      },
      {
        question: { text: "What year did the Berlin Wall fall?" },
        correctAnswer: "1989",
        incorrectAnswers: ["1975", "1991", "1985"]
      },
      {
        question: { text: "Who was the famous queen of ancient Egypt?" },
        correctAnswer: "Cleopatra",
        incorrectAnswers: ["Nefertiti", "Hatshepsut", "Neferure"]
      },
      {
        question: { text: "Which country was formerly known as Persia?" },
        correctAnswer: "Iran",
        incorrectAnswers: ["Iraq", "Turkey", "Afghanistan"]
      },
      {
        question: { text: "Who was the first man to walk on the Moon?" },
        correctAnswer: "Neil Armstrong",
        incorrectAnswers: ["Buzz Aldrin", "Yuri Gagarin", "Michael Collins"]
      },
      {
        question: { text: "In which year did the Titanic sink?" },
        correctAnswer: "1912",
        incorrectAnswers: ["1905", "1920", "1898"]
      },
      {
        question: { text: "What empire was ruled by Julius Caesar?" },
        correctAnswer: "Roman Empire",
        incorrectAnswers: ["Ottoman Empire", "Mongol Empire", "Byzantine Empire"]
      }
    ];

    return mockData;  // Return mock data when useMockData is true
  }

  // Actual API call if not using mock data
  try {
    const response = await fetch('https://opentdb.com/api.php?amount=5&type=multiple'); // Open Trivia Database API
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const data = await response.json();

    // Assuming the response has a structure like this:
    // data.results: Array of question objects with question text, correct_answer, and incorrect_answers
    return data.results.map((question) => ({
      question: { text: question.question },
      correctAnswer: question.correct_answer,
      incorrectAnswers: question.incorrect_answers,
    }));
  } catch (error) {
    console.error("Error fetching quiz data:", error);
    // If an error occurs, return mock data instead
    return fetchQuizData(true); // This ensures mock data is used in case of error
  }
};

export default fetchQuizData;
